# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 10:10:03 2021

@author: Pc
"""

### "TUSAŞ TARİFNAME YAZIM PROGRAMINA HOŞGELDİNİZ :)"

unsur_sayilari_listesi = []

#Yukarıda unsur sayıları listesini oluşturmak için boş bir liste atadık. Daha sonra buraya 1'den n'e kadar unsur sayilarini atayacağız.

toplam_unsur_sayisi = int (input('Toplam unsur sayisini giriniz: '))

#Kullanıcıdan toplam dahili unsur sayısını aldık. Bu sayıyı for döngüsü için kullanacağız.

for i in range (1,toplam_unsur_sayisi+1):
    unsur_sayilari_listesi.append (i)
    
#Yukarıda unsur sayiları listemizi 1'den n'e kadar boş listeye ekleye ekleye oluşturduk.

unsur_isimleri_listesi = []

#Yukarıda unsur isimleri listesini oluşturmak için boş bir liste atadık. Daha sonra buraya unsur isimlerini atayacağız.

for i in range (1, toplam_unsur_sayisi+1):
    unsur_isimleri_listesi.append (i)

#unsur_sayilari_listesi ile aynı üyeleri olan listeyi oluşturduk ki boş listemizde aynı sayıda unsurlar olsun. 
#Daha sonra bu unsurları değiştireceğiz.

for i in range (0, toplam_unsur_sayisi):
    
    unsur_isimleri_listesi [i] = input (str(unsur_sayilari_listesi [i]) + '. unsur ismini giriniz: ')
    
#Yukarıdaki for döngüsü ile kullanıcıdan kaç tane unsur ismi girdiyse her bir unsur ismini input olarak alıyoruz.

unsur_tanimlari_listesi = []

#Yukarıda, unsur tanımları için boş liste tanımlanmışır.

for i in range (1, toplam_unsur_sayisi+1):
    unsur_tanimlari_listesi.append (i)

#unsur_sayilari_listesi ile aynı üyeleri olan listeyi oluşturduk ki boş listemizde aynı sayıda unsur tanımları olsun. 
#Daha sonra gerçek unsur tanımlarını gireceğiz.

unsur_tanimlari_listesi [0]= ''

#1. unsurun tanımı olmadığı için 0. indexi yani 1. unsurun tanımını boş atadık.

for i in range (1, toplam_unsur_sayisi):
    
    unsur_tanimlari_listesi [i] = input (str(unsur_sayilari_listesi [i]) + '. unsur tanımını giriniz: ')
    
#Yukarıdaki for döngüsü ile 1. indexten n. idexe kadar, yani 2. unsurdan n. unsura kadar unsur tanımlarını aldık.

#----------------------------------------------------------------------------------

unsur_tanimlari_listesi_split = []

#Yukarıdaki kod ile istem cümlesi için boş bir liste atadık, böylelikle her bir unsur cümlesini aşağıda yazılan kodla ekleyip
#sonrasında bu ana istem cümlesinden index ile çekip cümleyi oluşturacağım.

for i in range (1, toplam_unsur_sayisi+1):
    unsur_tanimlari_listesi_split.append (i)

for i in range (1,toplam_unsur_sayisi):
    unsur_tanimlari_listesi_split [i] = unsur_tanimlari_listesi [i].split ()

unsur_tanimlari_listesi_split [0] = unsur_tanimlari_listesi [0]

###----BİR ÜSTTEKİ KISIMDAN BURAYA KADAR OLAN KISIMDA NE YAPTIĞIMI ANLAMAYA ÇALIŞ :D

unsur_isimleri_listesi_unsuz_yumusamasi_hali = []

for i in range (0,toplam_unsur_sayisi):
    unsur_isimleri_listesi_unsuz_yumusamasi_hali.append(unsur_isimleri_listesi [i])

unsuz_yumusamasi_harfleri_listesi = ['c','ğ','b','d']

gecici = ['']

for i in range (1, toplam_unsur_sayisi):
    if unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('ç'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [0]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)
    elif unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('k'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [1]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)
    elif unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('p'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [2]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)
    elif unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('t'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [3]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)

#-------------------UNSUR İSİMLERİNİN UNSUZ YUMUSAMASI HALLERİ LİSTESİNİN OLUŞTURULDUĞU KISIM BURAYA KADARKİ KISIM---------------
        
#-------ARTIK GEREKLİ TÜM LİSTE HAZIR, UNSUZ YUMUSAMASI İÇİN GEREKEN TÜM KOŞULLARI İF VE AND İLE AYNI KOMUTTA GİRİP UNSUZ YUMUSAMASI
#OLUP OLMADIĞINI TESPİT EDİCEZ, VARSA UNSUZ YUMUSAMALI LİSTEDEKİ HALİNDEN AL DİYECEĞİZ.



#-YUKARIDAKİ KODA EK İÇİN İLK HARFİN SESLİ HARF GELİP GELMEMESİ KOŞULU EKLENECEK. ÇÜNKÜ "DÖNER ÇUBUĞA" DA DEĞİŞMESİNİ İSTERİZ AMA "DÖNER ÇUBUKTAN" DA DEĞİŞMESİNİ İSTEMEYİZ. ÜNSÜZ YUMUŞAMASI EKİN İLK HARFİ ÜNLÜ HARF OLDUĞUNDA GERÇEKLEŞTİGİ İÇİN BUNU DA KODA KATMAM GEREKİYOR.

for i in range (1, toplam_unsur_sayisi):
    for index, item in enumerate (unsur_tanimlari_listesi_split [i]):
       if unsur_tanimlari_listesi_split [i] [index].startswith ("u1"):
          unsur_tanimlari_listesi_split [i] [index] = item + ' (1).'
       elif unsur_tanimlari_listesi_split [i] [index].startswith ("u2"):
          unsur_tanimlari_listesi_split [i] [index] = item + ' (2)'
       elif unsur_tanimlari_listesi_split [i] [index].startswith ("u3"):
          unsur_tanimlari_listesi_split [i] [index] = item + ' (3)'
       else:
          unsur_tanimlari_listesi_split [i] [index] = item

#-YUKARIDAKİ KOD İLE UNSURLARA PARANTEZLİ REFERANS NUMARALARI ATANDI UNSUR TANIMLARININ SPLIT VERSIYONU LISTESİNE

unsur_tanimlari_listesi_string = []

for i in range (0,toplam_unsur_sayisi):
    unsur_tanimlari_listesi_string.append(unsur_tanimlari_listesi_split [i])

#-UNSUR TANIMI LİSTESİNİN STRING HALİNE ÇEVİRMEMİZ GEREKİYOR REPLACE FONK. İÇİN. BURADA BUNUN İÇİN BOŞ LİSTE ATAYIP DOLDURDUK
#-DAHA SONRA DEĞİŞTİRMEK ÜZERE.

for i in range (1, toplam_unsur_sayisi):
   unsur_tanimlari_listesi_string [i] = ' '.join(unsur_tanimlari_listesi_string [i])

#- REPLACE FONKSİYONUNU GERÇEKLEŞTİREBİLMEK İÇİN TÜM İFADEYİ LİST'TEN STRING FORMATINA GERİ ÇEVİRDİK JOİN FONKSİYONU İLE.

for i in range (1, toplam_unsur_sayisi):       
   if unsur_isimleri_listesi [i].endswith('ç'):
      unsur_tanimlari_listesi_string [i] = unsur_tanimlari_listesi_string [i].replace("u2", unsur_isimleri_listesi_unsuz_yumusamasi_hali [1])
   else:
      unsur_tanimlari_listesi_string [i] = unsur_tanimlari_listesi_string [i].replace("u2", unsur_isimleri_listesi [1])

for i in range (1, toplam_unsur_sayisi):    
   if unsur_isimleri_listesi [i].endswith('k'):
      unsur_tanimlari_listesi_string [i] = unsur_tanimlari_listesi_string [i].replace("u3", unsur_isimleri_listesi_unsuz_yumusamasi_hali [2])
   else:
      unsur_tanimlari_listesi_string [i] = unsur_tanimlari_listesi_string [i].replace("u3", unsur_isimleri_listesi [2])

#- REPLACE FONKSİYONU İLE İLGİLİ UNSUR İSİMLERİNİ YERLERİNE YERLEŞTİRDİK. IF FONKSİYONU KULLANICAZ UNSUZ YUMUSAMASI OLMASINA GORE
#- ISLOWER VS CÜMLESİNİ BURAYA ENTEGRE ET. ŞUANKİ KISIM DA TAM ÇALIŞMIYOR. BURAYI DA HALLEDİP DÖNER ÇUBUĞU, DÖNER ÇUBUKTAN
#- ÖRNEĞİNE GÖRE DÜZENLE ÜST KISMI.