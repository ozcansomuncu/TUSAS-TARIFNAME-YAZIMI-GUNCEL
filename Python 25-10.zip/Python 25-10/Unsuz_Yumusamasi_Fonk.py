# -*- coding: utf-8 -*-
"""
Created on Fri Oct 22 10:13:09 2021

@author: t22375
"""

#----------------------UNSUZ YUMUSAMASI FONKSİYONU-----------------------------------------

toplam_unsur_sayisi = int(4)

unsur_isimleri_listesi = ['mühimmat destek sistemi', 'gövde', 'iletim çubuğu', 'döner çubuk']

#-------------------------ÜSTTEKİ KODLAR HIZLI DENEMEK İÇİN EKLENDİ, NORMALDE GEREK YOK--------------

unsur_isimleri_listesi_unsuz_yumusamasi_hali = []

for i in range (0,toplam_unsur_sayisi):
    unsur_isimleri_listesi_unsuz_yumusamasi_hali.append(unsur_isimleri_listesi [i])

unsuz_yumusamasi_harfleri_listesi = ['c','ğ','b','d']

gecici = ['']

for i in range (1, toplam_unsur_sayisi):
    if unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('ç'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [0]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)
    if unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('k'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [1]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)
    if unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('p'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [2]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)
    if unsur_isimleri_listesi_unsuz_yumusamasi_hali [i].endswith ('t'):
        gecici = list(unsur_isimleri_listesi_unsuz_yumusamasi_hali [i])
        gecici [-1] = unsuz_yumusamasi_harfleri_listesi [3]
        unsur_isimleri_listesi_unsuz_yumusamasi_hali [i] = ''.join(gecici)

#-------------------UNSUR İSİMLERİNİN UNSUZ YUMUSAMASI HALLERİ LİSTESİNİN OLUŞTURULDUĞU KISIM BURAYA KADARKİ KISIM---------------
        
#-------ARTIK GEREKLİ TÜM LİSTE HAZIR, UNSUZ YUMUSAMASI İÇİN GEREKEN TÜM KOŞULLARI İF VE AND İLE AYNI KOMUTTA GİRİP UNSUZ YUMUSAMASI
#OLUP OLMADIĞINI TESPİT EDİCEZ, VARSA UNSUZ YUMUSAMALI LİSTEDEKİ HALİNDEN AL DİYECEĞİZ.